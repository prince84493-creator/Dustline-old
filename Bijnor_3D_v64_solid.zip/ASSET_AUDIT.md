# Asset audit (before Play Store upload)

| Asset | Status | What to do |
|---|---|---|
| Plane, 13 guns | Own work (tools/make_plane.py, tools/make_guns.py) | Nothing |
| Survivor character | CGTrader Royalty Free (no AI), proof in proof_private/, files scrambled | Keep the download record |
| Store clothes (8), jump + reload motion | CC-BY-4.0, credited with changes notice | OK (credits.txt) |
| Parachute | CC-BY-4.0, credited | OK |
| HUD icons (ui/hud/*.png) | Made by you with ChatGPT (OpenAI); minimap icon redrawn (the old one was a crop of the real map) | OK. The airdrop crate (red / blue box) looks like a common battle-royale crate: redraw if you want zero resemblance |
| lobby_bg.jpg | Made by you with ChatGPT (OpenAI), no logos or brand | OK |
| loading_screen.jpg | Same file as lobby_bg.jpg (made with ChatGPT) | OK, declared in credits |
| character card frame | Original (Phase 74) | OK |
| Gun names | Real firearm names, no brand logos | OK |
| Sounds | Generated in code | OK |

## Sketchfab models: how to make them safe WITHOUT removing them
1. Put the original downloads (.glb) into `reference/sketchfab/`. For a model you only have baked, add a line to `tools/extra_credits.txt`.
2. Run `python3 tools/extract_credits.py`. It reads author / licence / link from each file, writes `CREDITS.md` and `assets/credits.txt` (shown in the game under Settings > ACCOUNT > CREDITS & LICENSES) and prints a verdict per model.
3. Verdicts:
   - **OK** (CC0, CC-BY): allowed in a commercial app, you only have to give credit (done by step 2).
   - **CHECK** (CC-BY-SA or no licence): read the licence page; share-alike can force the model files to stay open.
   - **STOP** (NonCommercial, NoDerivatives, Editorial, Standard): not allowed here (the app is distributed commercially and the models are modified / baked). Replace the model, or get written permission from the author.
4. Also paste the same credit lines into the Play Store full description.
5. Do not use models that were ripped from other games (not from Sketchfab creators), even if they sit on Sketchfab.

Status v1.0.6: nothing is waiting for a check any more. Every model is own work or has a verified licence (see ASSET_LICENSES.md). The steps above are only for a model you add LATER.
