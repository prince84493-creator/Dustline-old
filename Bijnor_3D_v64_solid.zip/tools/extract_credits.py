#!/usr/bin/env python3
"""Builds the credits of every Sketchfab model automatically.

A .glb / .gltf downloaded from Sketchfab carries its author, licence, title and source URL inside the file
(asset.extras). Put the ORIGINAL downloads of your models (character, parachute, animations, clothes ...) into
reference/sketchfab/ (any sub-folders), then run from the project root:

    python3 tools/extract_credits.py

It rewrites CREDITS.md and app/src/main/assets/credits.txt (shown in-game: Settings > ACCOUNT > CREDITS & LICENSES)
and prints a verdict per model:
    OK     CC0 / CC-BY (just credit - done by this script)
    CHECK  CC-BY-SA or unknown licence (read the licence; share-alike can reach your app)
    STOP   NonCommercial (NC), NoDerivatives (ND) or "Editorial" / "Standard" licences: NOT allowed in a commercial app
           -> replace the model or ask the author in writing.
Models without a .glb: add one line each to tools/extra_credits.txt:  Title | Author | Licence | URL
"""
import json, os, struct, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCAN = [os.path.join(ROOT, 'reference')]
CC_URL = "https://creativecommons.org/licenses/by/4.0/"
CC_LEGAL = "https://creativecommons.org/licenses/by/4.0/legalcode"
SHOWN_AS = {  # how the work appears in the game
}
# "Changes made" (CC BY 4.0 section 3(a)(1)(B)) - keyed by the last 32 characters of the source URL (the Sketchfab model id) or a title
MODS = {
 "030a235d6f314a86bebc33f322c0e71c": "Used as the player's parachute. Converted from glTF to the game's own binary mesh format (parachute.bin), texture re-saved as a smaller JPEG, scaled to game metres and re-oriented; colours / texture adjusted for the game.",
 "8dc73a1346424e53ad02fb05163ead13": "Only the MOTION of the jump clip is used: 14 joint rotations were sampled at 30 fps and re-targeted onto the game's own character rig. No mesh, texture or skeleton of this model is in the game.",
 "662fc74dda2646cfb48fc610705768ef": "Only the MOTION of the 'Reload' clip is used: 5 joints were sampled (56 frames), re-scaled and re-targeted onto the game's own guns and hands. No mesh or texture of this pack is in the game.",
 "00daf5abf6d44db9a310b8264ad0e834": "Shown in the in-game store as 'RAGLAN TEE'. Converted to the game's own format, re-fitted to the game's survivor character and skinned to its 11-bone rig, colours / textures reduced, scaled.",
 "a8381c06f8084c5499865ac7b5e59a0b": "Shown in the in-game store as 'HENLEY TEE'. Converted to the game's own format, re-fitted to the game's survivor character and skinned to its 11-bone rig, colours / textures reduced, scaled.",
 "408000a9975a4c34866b42dfaca4fa75": "Shown in the in-game store as 'WHITE TEE'. Converted to the game's own format, re-fitted to the game's survivor character and skinned to its 11-bone rig, colours / textures reduced, scaled.",
 "50fc69ff7a9a4f91ad721b44e898772d": "Shown in the in-game store as 'OLIVE SWEATER'. Converted to the game's own format, re-fitted to the game's survivor character and skinned to its 11-bone rig, colours / textures reduced, scaled.",
 "FREE Survival Character (+11 textures)": "Used as the player's survivor character. Converted to the game's own binary mesh format (vertices split at UV / normal seams for OpenGL) and stored scrambled inside the app so that it cannot be extracted as a separate file, as the licence requires. Not used to train or feed any AI.",
 "fd88987f8e5541ada74e222612f5b48b": "No mesh, texture or animation data of this model is contained in the current game; the credit is kept to be safe.",
}
NO_ENDORSE = "The original authors did not create, review or endorse this game."
MODIFIED_BY = "All changes listed under 'Changes made' (or 'Changes') were made by the developer of Bijnor. Where a work says it was changed, the version in this game is an adapted version, not the original."
CGT_LICENSE_URL = "https://help.cgtrader.com/hc/en-us/articles/360015193418"
DISCLAIMER = "Works are provided by their authors under their licences 'as is', without warranties - see the disclaimer in the licence text: " + CC_LEGAL
AI_LINES = [
    "Lobby background, loading screen and menu / HUD icons: created by the developer with ChatGPT (OpenAI, image generation) and used under OpenAI's Terms of Use, which give the user the rights to the output, including commercial use.",
    "Sounds are generated in code. Game code by the developer.",
    "Aircraft (passenger jet): designed with AI assistance and owned by the developer (tools/make_plane.py).",
    "Reload animation motion: see 'M4 - FPS Weapon Animations Pack' above; jump motion: see 'Human character with jumping animation' above.",
    "Guns (13 weapon models): created procedurally by the developer (tools/make_guns.py), original work.",
    "Store clothes (6 pants: BLUE DENIM JEANS, CHARCOAL CARGO PANTS, OLIVE CAMO PANTS, BLACK TRACK PANTS, RED TARTAN PANTS, EMBER FLAME PANTS; 2 T-shirts: DESERT STRIPE TEE, CROSSHAIR V-NECK): designed with AI assistance (Claude, by Anthropic) and owned by the developer - original work, the 3D meshes and colours are generated by code (tools/make_clothes.py); no third-party model, texture or photo is used, no attribution needed.",
    "Open-source libraries: AndroidX Core / AppCompat (Apache License 2.0, https://www.apache.org/licenses/LICENSE-2.0).",
]

def read_extras(path):
    with open(path, 'rb') as f:
        data = f.read()
    if path.lower().endswith('.glb'):
        if data[:4] != b'glTF':
            return None
        ln, typ = struct.unpack('<II', data[12:20])
        js = json.loads(data[20:20 + ln].decode('utf-8'))
    else:
        js = json.loads(data.decode('utf-8'))
    ex = (js.get('asset') or {}).get('extras') or {}
    return {k: str(ex.get(k, '')).strip() for k in ('title', 'author', 'license', 'source')}

def verdict(lic):
    u = lic.upper().replace(' ', '')
    if not u: return 'CHECK'
    if 'NC' in u.replace('CC-BY','').replace('CC0','') or '-ND' in u or 'EDITORIAL' in u or 'STANDARD' in u: return 'STOP'
    if 'CC0' in u or 'PUBLICDOMAIN' in u: return 'OK'
    if 'ROYALTYFREE' in u: return 'OK'   # CGTrader Royalty Free (no AI): OK in a game if users cannot extract the file (see proof_private/CHARACTER_LICENSE.md)
    if '-SA' in u: return 'CHECK'
    if 'CC-BY' in u: return 'OK'
    return 'CHECK'

def main():
    items, seen = [], set()
    for base in SCAN:
        for r, _, fs in os.walk(base):
            for fn in sorted(fs):
                if fn.lower().endswith(('.glb', '.gltf')):
                    p = os.path.join(r, fn)
                    try: e = read_extras(p)
                    except Exception as ex: print('cannot read', p, ex); continue
                    if e is None: continue
                    e['file'] = os.path.relpath(p, ROOT)
                    if not e['title']: e['title'] = os.path.splitext(fn)[0]
                    items.append(e); seen.add(e['source'] or e['file'])
    xp = os.path.join(ROOT, 'tools', 'extra_credits.txt')
    if os.path.exists(xp):
        for ln in open(xp, encoding='utf-8'):
            ln = ln.strip()
            if not ln or ln.startswith('#'): continue
            a = [x.strip() for x in ln.split('|')] + ['', '', '', '']
            items.append({'title': a[0], 'author': a[1], 'license': a[2], 'source': a[3], 'file': 'extra_credits.txt'})
    worst = 'OK'
    rows = []
    for e in items:
        v = verdict(e['license']); rows.append((v, e))
        if v == 'STOP': worst = 'STOP'
        elif v == 'CHECK' and worst != 'STOP': worst = 'CHECK'
        print('%-5s %-32s %-28s %s' % (v, e['title'][:32], e['license'][:28], e['file']))
    md = ['# Credits', '', 'Every work below that is marked CC BY 4.0 is licensed under ' + CC_URL + ' (CC BY 4.0).', '']
    txt = ['CREDITS & LICENSES', '', 'Works marked "CC BY 4.0" are licensed under the Creative Commons Attribution 4.0 International licence: ' + CC_URL, '']
    store = []
    for v, e in rows:
        lic = e['license'] or '?'
        is_cc = 'CC-BY' in lic.upper().replace(' ', '')
        lic_show = 'CC BY 4.0 - ' + CC_URL if is_cc else (lic + ' - ' + CGT_LICENSE_URL if 'ROYALTY' in lic.upper() else lic)
        key = (e['source'] or '')[-32:]
        mod = MODS.get(key) or MODS.get(e['title'], '')
        auth = e['author'] or '?'
        block = ['"%s" by %s' % (e['title'], auth), 'Source: ' + (e['source'] or '?'), 'License: ' + lic_show]
        if is_cc: block.append('Changes made: ' + (mod or 'converted / adapted for this game.'))
        elif mod: block.append('Changes: ' + mod)
        md.append('- ' + '\n  '.join(block))
        txt.append('\n'.join(block) + '\n')
        store.append('"%s" by %s - %s - %s%s' % (e['title'], auth.split(' (')[0], e['source'] or '?', 'CC BY 4.0' if is_cc else lic, ' (changed: ' + mod + ')' if is_cc and mod else ''))
    md += ['', MODIFIED_BY, '', NO_ENDORSE, '', DISCLAIMER, ''] + ['- ' + l for l in AI_LINES]
    txt += [MODIFIED_BY, '', NO_ENDORSE, '', DISCLAIMER, ''] + AI_LINES
    open(os.path.join(ROOT, 'CREDITS.md'), 'w', encoding='utf-8').write('\n'.join(md) + '\n')
    ap = os.path.join(ROOT, 'app', 'src', 'main', 'assets')
    open(os.path.join(ap, 'credits.txt'), 'w', encoding='utf-8').write('\n'.join(txt) + '\n')
    # keep manifest.txt size of credits.txt right
    mp = os.path.join(ap, 'manifest.txt')
    if os.path.exists(mp):
        sz = os.path.getsize(os.path.join(ap, 'credits.txt')); out = []; found = False
        for l in open(mp, encoding='utf-8').read().splitlines():
            if l.startswith('credits.txt|'): l = 'credits.txt|%d' % sz; found = True
            out.append(l)
        if not found: out.append('credits.txt|%d' % sz)
        open(mp, 'w', encoding='utf-8').write('\n'.join(out) + '\n')
    print('\n%d models listed. Overall: %s' % (len(rows), worst))
    if worst == 'STOP': print('At least one model has a licence that does not allow your app (NC / ND / Editorial). Replace it.')
    sys.exit(0 if worst != 'STOP' else 2)

if __name__ == '__main__':
    main()
